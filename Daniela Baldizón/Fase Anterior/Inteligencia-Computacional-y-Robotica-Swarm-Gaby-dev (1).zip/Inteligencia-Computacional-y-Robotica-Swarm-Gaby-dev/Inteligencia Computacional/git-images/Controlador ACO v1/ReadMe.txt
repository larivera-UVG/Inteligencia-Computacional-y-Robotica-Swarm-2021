En este no hice la interpolación,
sino que solo pasé las metas
sin procesar, directo del ACO.